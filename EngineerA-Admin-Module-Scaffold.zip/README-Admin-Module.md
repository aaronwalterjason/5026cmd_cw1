# Engineer A — Administrator Module scaffold

This is a starting skeleton for the Admin module of RROMS (5026CMD coursework), built as an
ASP.NET Core **Area** so it drops into an existing Razor Pages solution without colliding with
the Staff or Customer areas your teammates own.

## What's here

```
Areas/Admin/Pages/
  _ViewImports.cshtml        shared usings + tag helpers for every page in this area
  Index.cshtml(.cs)          admin dashboard (stat tiles → replace with real counts)
  DiningAreas/                *** full CRUD — copy this pattern for everything else ***
    Index / Create / Edit / Delete  (.cshtml + .cshtml.cs each)
  Tables/Index(.cs)          stub list — build Create/Edit/Delete from DiningAreas
  MenuCategories/Index(.cs)  stub list — same
  MenuItems/Index(.cs)       stub list — same, plus a Promotion link (Advanced tier)
  Reports/Index(.cs)         date-range filter shell (Intermediate → Advanced tier)
  Accounts/Index(.cs)        blocked on B's Identity/RBAC — commented-out UserManager calls
  Settings/Index(.cs)        opening hours + announcement banner form
  Shared/_AdminNav.cshtml    side-nav partial to drop into the shared site layout

Models/Admin/
  DiningArea.cs, RestaurantTable.cs, MenuCategory.cs, MenuItem.cs, Promotion.cs
```

Every PageModel is decorated `[Authorize(Roles = "Administrator")]` and has its DbContext calls
**commented out** rather than deleted — wire them up once the shared pieces below exist, instead
of guessing at names now and rewriting later.

## Assumptions this scaffold makes (check these against the real project)

- Project root namespace is `RROMS` (rename the `namespace` line in every file if not).
- There will be one shared `ApplicationDbContext` (Engineer A drives this — see the master plan)
  with `DbSet<DiningArea>`, `DbSet<RestaurantTable>`, `DbSet<MenuCategory>`, `DbSet<MenuItem>`,
  `DbSet<Promotion>` added to it.
- Auth uses ASP.NET Core Identity with three roles: `"Administrator"`, `"Staff"`, `"Customer"`
  (Engineer B drives this — the Accounts page and every `[Authorize(Roles=...)]` attribute depend
  on it existing).
- The shared Bootstrap layout (Engineer C drives this) exposes a `_Layout.cshtml` these pages
  render into automatically, and has a slot to render `_AdminNav.cshtml` when the path is
  `/Admin/*`.

## How to wire it in

1. Copy `Areas/` and `Models/` into your ASP.NET Core project root, merging folders if they
   already exist.
2. Add the five `DbSet<>` properties above to your `ApplicationDbContext`, then:
   ```
   dotnet ef migrations add AddAdminEntities
   dotnet ef database update
   ```
3. Uncomment the constructor + DbContext lines in each `.cshtml.cs` file and delete the sample
   data in `DiningAreas/Index.cshtml.cs` once real data flows.
4. Seed the three Identity roles and at least one Administrator account (Engineer B's task, but
   you'll need it locally to test — ask them for the seeding snippet or add a temporary one).
5. Render `Shared/_AdminNav.cshtml` from the site's main layout when the current path starts with
   `/Admin` (a one-line `@await Html.PartialAsync(...)` behind an `if` in `_Layout.cshtml`).

## Build order (matches the master timeline)

| Week | Do this |
|---|---|
| 2–3 | Design the ER schema for these 5 entities, run the first migration, get the dashboard rendering with zero data |
| 4–6 | Copy the DiningAreas CRUD pattern into Tables, MenuCategories, MenuItems; wire Accounts once B's Identity lands |
| 7–8 | Build out Reports/Index with real filtered queries against B's Reservations/Orders tables |
| 9 | Analytics dashboard (charts) + CSV/PDF/Excel export on Reports |
| 10 | Polish, screenshots and code excerpts for report Chapter 5, final testing |

Full context (role split, WBS, Gantt, marking-criteria checklist) is in the team's **RROMS Project
Plan** artifact and your own **Engineer A Playbook** artifact.
