using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RROMS.Models.Admin;
// using RROMS.Data;

namespace RROMS.Areas.Admin.Pages.Tables
{
    // TODO (Basic tier, Week 4-6): copy the Create/Edit/Delete pattern from
    // Areas/Admin/Pages/DiningAreas/ for this entity. This Index is a starting stub only.
    [Authorize(Roles = "Administrator")]
    public class IndexModel : PageModel
    {
        // private readonly ApplicationDbContext _db;
        // public IndexModel(ApplicationDbContext db) => _db = db;

        public IList<RestaurantTable> Tables { get; set; } = new List<RestaurantTable>();

        public void OnGet()
        {
            // Tables = _db.RestaurantTables.Include(t => t.DiningArea).OrderBy(t => t.TableNumber).ToList();
        }
    }
}
