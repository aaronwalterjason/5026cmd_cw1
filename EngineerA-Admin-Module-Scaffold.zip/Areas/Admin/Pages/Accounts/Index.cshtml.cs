using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
// using Microsoft.AspNetCore.Identity;
// using RROMS.Data;

namespace RROMS.Areas.Admin.Pages.Accounts
{
    // DEPENDS ON Engineer B's Identity/RBAC setup (Week 2-3 foundation task).
    // Once UserManager<ApplicationUser> / RoleManager<IdentityRole> exist, list users here
    // and let the admin assign/change roles (Administrator / Staff / Customer).
    [Authorize(Roles = "Administrator")]
    public class IndexModel : PageModel
    {
        // private readonly UserManager<ApplicationUser> _userManager;
        // public IndexModel(UserManager<ApplicationUser> userManager) => _userManager = userManager;

        public List<(string Email, string Role)> Accounts { get; set; } = new();

        public void OnGet()
        {
            // Accounts = _userManager.Users
            //     .Select(u => (u.Email!, _userManager.GetRolesAsync(u).Result.FirstOrDefault() ?? "Customer"))
            //     .ToList();
        }
    }
}
