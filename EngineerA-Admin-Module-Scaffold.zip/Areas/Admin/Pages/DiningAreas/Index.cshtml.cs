using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RROMS.Models.Admin;
// using RROMS.Data;
// using Microsoft.EntityFrameworkCore;

namespace RROMS.Areas.Admin.Pages.DiningAreas
{
    [Authorize(Roles = "Administrator")]
    public class IndexModel : PageModel
    {
        // private readonly ApplicationDbContext _db;
        // public IndexModel(ApplicationDbContext db) => _db = db;

        public IList<DiningArea> DiningAreas { get; set; } = new List<DiningArea>();

        public void OnGet()
        {
            // DiningAreas = _db.DiningAreas.Include(d => d.Tables).OrderBy(d => d.Name).ToList();

            // Sample data so the page renders before the DbContext is wired up - delete once real data flows.
            DiningAreas = new List<DiningArea>
            {
                new DiningArea { Id = 1, Name = "Main Hall", Zone = "Indoor", IsActive = true },
                new DiningArea { Id = 2, Name = "Rooftop", Zone = "Outdoor", IsActive = true },
            };
        }
    }
}
