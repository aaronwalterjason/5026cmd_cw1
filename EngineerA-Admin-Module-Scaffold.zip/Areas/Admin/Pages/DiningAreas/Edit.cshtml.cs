using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RROMS.Models.Admin;
// using RROMS.Data;

namespace RROMS.Areas.Admin.Pages.DiningAreas
{
    [Authorize(Roles = "Administrator")]
    public class EditModel : PageModel
    {
        // private readonly ApplicationDbContext _db;
        // public EditModel(ApplicationDbContext db) => _db = db;

        [BindProperty]
        public DiningArea DiningArea { get; set; } = new();

        public IActionResult OnGet(int id)
        {
            // var area = _db.DiningAreas.Find(id);
            // if (area is null) return NotFound();
            // DiningArea = area;

            DiningArea = new DiningArea { Id = id, Name = "Main Hall", Zone = "Indoor", IsActive = true };
            return Page();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            // _db.DiningAreas.Update(DiningArea);
            // _db.SaveChanges();

            TempData["StatusMessage"] = $"'{DiningArea.Name}' was updated.";
            return RedirectToPage("./Index");
        }
    }
}
