using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RROMS.Models.Admin;
// using RROMS.Data;

namespace RROMS.Areas.Admin.Pages.DiningAreas
{
    [Authorize(Roles = "Administrator")]
    public class CreateModel : PageModel
    {
        // private readonly ApplicationDbContext _db;
        // public CreateModel(ApplicationDbContext db) => _db = db;

        [BindProperty]
        public DiningArea DiningArea { get; set; } = new();

        public void OnGet() { }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            // _db.DiningAreas.Add(DiningArea);
            // _db.SaveChanges();

            TempData["StatusMessage"] = $"'{DiningArea.Name}' was created.";
            return RedirectToPage("./Index");
        }
    }
}
