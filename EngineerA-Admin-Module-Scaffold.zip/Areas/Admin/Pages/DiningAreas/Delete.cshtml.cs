using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RROMS.Models.Admin;
// using RROMS.Data;

namespace RROMS.Areas.Admin.Pages.DiningAreas
{
    [Authorize(Roles = "Administrator")]
    public class DeleteModel : PageModel
    {
        // private readonly ApplicationDbContext _db;
        // public DeleteModel(ApplicationDbContext db) => _db = db;

        [BindProperty]
        public DiningArea DiningArea { get; set; } = new();

        public IActionResult OnGet(int id)
        {
            // var area = _db.DiningAreas.Find(id);
            // if (area is null) return NotFound();
            // DiningArea = area;

            DiningArea = new DiningArea { Id = id, Name = "Main Hall", Zone = "Indoor" };
            return Page();
        }

        public IActionResult OnPost()
        {
            // TODO: block delete (or cascade with confirmation) if the area still has tables,
            // and check Engineer B's reservation table for a foreign-key reference first.
            // var area = _db.DiningAreas.Find(DiningArea.Id);
            // if (area is not null) { _db.DiningAreas.Remove(area); _db.SaveChanges(); }

            TempData["StatusMessage"] = "Dining area was deleted.";
            return RedirectToPage("./Index");
        }
    }
}
