using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
// TODO: point this at your real DbContext namespace once B's auth/DbContext work lands.
// using RROMS.Data;

namespace RROMS.Areas.Admin.Pages
{
    [Authorize(Roles = "Administrator")]
    public class IndexModel : PageModel
    {
        // private readonly ApplicationDbContext _db;
        // public IndexModel(ApplicationDbContext db) => _db = db;

        public int DiningAreaCount { get; set; }
        public int TableCount { get; set; }
        public int MenuItemCount { get; set; }
        public int ActivePromotionCount { get; set; }

        public void OnGet()
        {
            // TODO: replace with real counts once DbContext is wired in, e.g.:
            // DiningAreaCount = _db.DiningAreas.Count();
            // TableCount = _db.RestaurantTables.Count();
            // MenuItemCount = _db.MenuItems.Count();
            // ActivePromotionCount = _db.Promotions.Count(p => p.IsActive);
        }
    }
}
