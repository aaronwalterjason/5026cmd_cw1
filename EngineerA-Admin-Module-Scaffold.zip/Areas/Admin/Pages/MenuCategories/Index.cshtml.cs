using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RROMS.Models.Admin;
// using RROMS.Data;

namespace RROMS.Areas.Admin.Pages.MenuCategories
{
    // TODO (Basic tier, Week 4-6): copy the DiningAreas CRUD pattern for this entity.
    [Authorize(Roles = "Administrator")]
    public class IndexModel : PageModel
    {
        public IList<MenuCategory> Categories { get; set; } = new List<MenuCategory>();

        public void OnGet()
        {
            // Categories = _db.MenuCategories.OrderBy(c => c.DisplayOrder).ToList();
        }
    }
}
