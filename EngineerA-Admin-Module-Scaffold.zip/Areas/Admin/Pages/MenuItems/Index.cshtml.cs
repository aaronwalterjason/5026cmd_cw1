using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RROMS.Models.Admin;
// using RROMS.Data;

namespace RROMS.Areas.Admin.Pages.MenuItems
{
    // TODO (Basic tier, Week 4-6): Create/Edit/Delete + image upload, following the
    // DiningAreas pattern. Promotion linking is Advanced tier (Week 9).
    [Authorize(Roles = "Administrator")]
    public class IndexModel : PageModel
    {
        public IList<MenuItem> Items { get; set; } = new List<MenuItem>();

        public void OnGet()
        {
            // Items = _db.MenuItems.Include(i => i.MenuCategory).Include(i => i.Promotion).ToList();
        }
    }
}
