using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
// using RROMS.Data;

namespace RROMS.Areas.Admin.Pages.Settings
{
    // Basic tier: operating hours. Intermediate/Advanced: announcements, promo campaign toggles.
    [Authorize(Roles = "Administrator")]
    public class IndexModel : PageModel
    {
        [Microsoft.AspNetCore.Mvc.BindProperty]
        public TimeOnly OpeningTime { get; set; } = new(10, 0);

        [Microsoft.AspNetCore.Mvc.BindProperty]
        public TimeOnly ClosingTime { get; set; } = new(22, 0);

        [Microsoft.AspNetCore.Mvc.BindProperty]
        public string AnnouncementText { get; set; } = string.Empty;

        public void OnGet()
        {
            // TODO: load from a Settings/RestaurantProfile table.
        }

        public void OnPost()
        {
            // TODO: persist OpeningTime/ClosingTime/AnnouncementText.
        }
    }
}
